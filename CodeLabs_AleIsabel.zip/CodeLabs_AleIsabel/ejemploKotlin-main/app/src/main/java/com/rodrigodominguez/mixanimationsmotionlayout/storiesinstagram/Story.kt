package com.rodrigodominguez.mixanimationsmotionlayout.storiesinstagram

import androidx.annotation.ColorInt

data class Story(
    @ColorInt val backgroundColor: Int
)