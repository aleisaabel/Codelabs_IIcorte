package com.rodrigodominguez.mixanimationsmotionlayout.storiesinstagram

data class StoryModel(
    val cardTop: Story,
    val cardBottom: Story
)
