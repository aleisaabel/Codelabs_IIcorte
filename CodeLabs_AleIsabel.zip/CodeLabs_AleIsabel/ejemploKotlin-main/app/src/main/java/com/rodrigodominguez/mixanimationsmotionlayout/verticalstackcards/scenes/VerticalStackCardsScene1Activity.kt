package com.rodrigodominguez.mixanimationsmotionlayout.verticalstackcards.scenes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.rodrigodominguez.mixanimationsmotionlayout.R

class VerticalStackCardsScene1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vertical_stack_cards_scene1)
    }
}